I have written this file in English as the assignment was in English, and also to showcase my proficiency in the language :)

This program is an image labeling application built with JavaScript, HTML, and CSS. It allows the user to upload an image, label it by clicking on the corners of a license plate, and save the coordinates of the 
labeled points in a JSON file. 
Saved JSON file will have the following structure(example with 3 images):

[
  {
    "id": 1674528576842,
    "coordinates": {
      "top_left": { "x": 219, "y": 315 },
      "bot_left": { "x": 220, "y": 364 },
      "top_right": { "x": 297, "y": 327 },
      "bot_right": { "x": 298, "y": 379 }
    }
  },
  {
    "id": 1674528599353,
    "coordinates": {
      "top_left": { "x": 219, "y": 315 },
      "bot_left": { "x": 220, "y": 364 },
      "top_right": { "x": 297, "y": 327 },
      "bot_right": { "x": 298, "y": 379 }
    }
  },
  {
    "id": 1674528624102,
    "coordinates": {
      "top_left": { "x": 219, "y": 315 },
      "bot_left": { "x": 220, "y": 364 },
      "top_right": { "x": 297, "y": 327 },
      "bot_right": { "x": 298, "y": 379 }
    }
  }
]




Here are the steps for using the program:

1.Click on the "Upload Image" button. This will open a file dialog for the user to select an image.

2.Once the image is selected, it will be displayed on the canvas element in the center of the page.

3.The user will be prompted to click on the top left corner of the license plate in the image. Once the user clicks on the correct location, a green dot will be displayed on the canvas to indicate the point.
Repeat the same process for: bottom left, top right and bottom right corner.

4.Once all four points have been labeled, the user will be prompted to save the coordinates by clicking on the "Save" button. This will create a JSON file containing the coordinates of the labeled points and the image ID
which will be downloaded to the user's computer.

5.If the user wants to label another image, they can click on the "Upload Next Image" button to repeat the process.



As you can see, while I focused more on functionality over aesthetics, I still made sure to maintain a visually pleasing appearance.

Web App can be tested by clicking the following link:
https://classy-cascaron-194ddf.netlify.app/
Please note that for some reason program does not work in Google Chrome. I think it is because the fileSaver function is from a libary that is not supported.

I hope this is what the assignment required and that you you like it :)

